Note:
These files may vary from the originals intended by the author.  They were hand corrected by me, Mattel Aquarius (Jason).  

Errors resulted from problems with Quicktype on the emulator and packed lines.  There were errors in the source text, also.

One file was deliberately altered by me.  I call it Track+.  I made the trail 4 characters wide, and changed the trail pattern from dots to black.
In this form, it reminds me of a favorite COCO one-liner.

Note2:  Additional editing done by James:
Further repairs to programs
Added brief instructions to some title screens
Added back the copyright symbol and the dot symbol, which Quicktype doesn't recognize

Gunfight
The outlaws are coming into town.  You must shoot them as they crouch, but before they can shoot you.  Each is faster than the one before.  Shoot with keys 1-5

Gambler
You bet on a number appearing on any of three dice to win your stake, times the number of dice your winning number appears on.

Moonlander
< Left
> Right
Z Up
Land on the flat area of the moon using your graphic display and instrument panel.  On landing, speeds of over + or -0.5 will destroy your lander.  Your panel displays fuel, horizontal and vertical velocities, and height.

Tracker
< Left
> Right
Z Thrust
Follow the trail left by the intruder and catch it.

Nim
Take turns to remove from 1 to 5 tokens from any group.  The player who takes the last token wins.  The computer plays cleverly and is difficult to beat!

Snake
< Left
> Right
A Up
Z Down
Hit the letters in order.  Once moving you can't stop.  Touching the walls or a wrong letter ends the game.  The first screen shows 11 letters, the others each add five more.  You win on reaching Z.

Masterguess
You have fifteen tries to find the computer's three digit number.  No two digits are alike.
Hit = number and position correct
Close = number only correct
Miss = Number and position wrong
Use keys 0-9

Symon
Use keys 1-6 to copy the increasing sequence.  You are allowed three mistakes.

Bomber
Z Bomb
> Missile
Flatten the city and land on the cleared space without hitting the buildings.  Bombs add to your score and remove seven floors from buildings.  The three missiles do not score but clear up to two rows below you.

Hi-lo
Bet in $10.00 units on the turn of the next card.  Use the H, L, and numeric keys.  Will you be a winner?

