Turn Word Wrap ON if you're using Notepad.

See also the readme.txt in the docs directory.

This is the Quick Start document.

First, unzip the files into a directory, e.g. c:\VAquarius.

Cool.

Then double-click on the AQUARIUS icon.

The emulator should now be running.

Press the RETURN key because it tells you to!



From the file menu, select Quick Type..., and from the quicktyp/GraphicFun directory, open colors.TXT.

type run
Follow the instructions on the screen!

==

After you've watched the color bars, go and read the readme.txt that's in the DOCS directory!

You can Quicktype other program text files too.

Also, CLOAD works on CAQ files.  For more information about those, see the readme.txt that's in the DOCS directory, and the readme_c.txt that's in the cassette directory.

The other software form is ROM cartridge images -- load these using Load Game ROM... on the File menu.  Some game ROMs are in the rom directory.

Enjoy!
James the Animal Tamer
2002, 2005, 2008
www.geocities.com/emucompboy

