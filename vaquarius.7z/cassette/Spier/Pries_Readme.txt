Pries BASIC with cursor NAVIGATION

Now, existing lines can be edited easely. There is no need to retype the whole
line just to make small changes.

Also:
- No cursor during program execution.
- Automatic key-repeat.
- Increase from 38 to 40 characters per line.
 
Pries BASIC funct�on keys
----------------------------------------
ctl + Q     shift-lock on/off
ctl + E     cursor up
ctl + U     erase a line
ctl + I     insert mode on/off
ctl + S     cursor left
ctl + D     cursor right
ctl + F     delete character
ctl + G     bell
ctl + H     backspace
ctl + J     cursor down ( chr$(10) )
ctl + K     clear screen
ctl + L     home
ctl + X     cursor down
ctl + C     skip a line
ctl + M     return ( chr$(13) )
ctl + shift wait

Using the Virtual Aquarius by James you could reconfigure your keyboard and
assign your PC control keys (left, right, up, down, insert, delete, home etc)
to the PRIES function keys.