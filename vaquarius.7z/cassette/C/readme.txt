
These programs were compiled for the Aquarius by a chap who wrote a z80 C runtime library for the Aquarius!  Unfortunately, I don't remember his name, or where to get the runtime library or compiler!

It might have been Stefano, and this might be where to get it:

Small C development for several z80 computers, including Aquarius
http://z88dk.sourceforge.net/
