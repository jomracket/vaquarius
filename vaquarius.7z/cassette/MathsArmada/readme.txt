5) Maths Armada - Why is the word "Armada" misspelled within the game itself?  It's called "Amarda."  Anyway, my son and I enjoyed a couple grueling games of this just before I made this ReadMe.
