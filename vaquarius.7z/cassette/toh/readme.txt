Tablets of Hippocrates.
Text adventure.
The author wrote several versions for various microcomputers.
The verb to get an object is "take"
